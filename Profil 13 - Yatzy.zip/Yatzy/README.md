Yatzy Refactoring Kata Java Version
===================================

For full instructions see [top level instructions](../README.md)

There are three variants of this kata each with different refactoring challenges.

## Code Reading Practice
Here is a list of github urls of all the YatzyCalculator Java classes:

* [Yatzy1](https://github.com/emilybache/Yatzy-Refactoring-Kata/blob/main/java/src/main/java/org/codingdojo/yatzy1/Yatzy1.java)
* [Yatzy2](https://github.com/emilybache/Yatzy-Refactoring-Kata/blob/main/java/src/main/java/org/codingdojo/yatzy2/Yatzy2.java)
* [Yatzy3](https://github.com/emilybache/Yatzy-Refactoring-Kata/blob/main/java/src/main/java/org/codingdojo/yatzy3/Yatzy3.java)
