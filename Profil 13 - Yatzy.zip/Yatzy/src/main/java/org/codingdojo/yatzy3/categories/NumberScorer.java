package org.codingdojo.yatzy3.categories;

import java.util.List;

public class NumberScorer extends CategoryScorer {
    private final int diceReadNumber;

    public NumberScorer(int diceReadNumber) {
        this.diceReadNumber = diceReadNumber;
    }

    @Override
    public int calculateScore(List<Integer> dice) {
        return frequencies(dice).get(diceReadNumber) * diceReadNumber;
    }
}
