package org.codingdojo.yatzy3.categories;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class RepeatedCountScorer extends CategoryScorer {
    private final int diceReadNumberFrequency;

    public RepeatedCountScorer(int diceReadNumberFrequency) {
        this.diceReadNumberFrequency = diceReadNumberFrequency;
    }

    @Override
    public int calculateScore(List<Integer> dice) {
        Map<Integer, Integer> frequencies = frequencies(dice);
        for (int i : Arrays.asList(6, 5, 4, 3, 2, 1)) {
            if (frequencies.get(i) >= diceReadNumberFrequency) {
                return i * diceReadNumberFrequency;
            }
        }
        return 0;
    }
}
