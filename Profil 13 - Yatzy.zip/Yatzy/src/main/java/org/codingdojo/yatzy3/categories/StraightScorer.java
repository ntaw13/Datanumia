package org.codingdojo.yatzy3.categories;

import java.util.List;

public class StraightScorer extends CategoryScorer {
    private final int straightScore;

    public StraightScorer(int straightScore) {
        this.straightScore = straightScore;
    }

    boolean noDiceRepetition(List<Integer> dice) {
        return frequencies(dice).values().stream().filter(f -> f == 1).toList().size() == dice.size();
    }
    @Override
    public int calculateScore(List<Integer> dice) {
        if (noDiceRepetition(dice) && sum(dice)== straightScore) {
            return sum(dice);
        }
        return 0;
    }
}
