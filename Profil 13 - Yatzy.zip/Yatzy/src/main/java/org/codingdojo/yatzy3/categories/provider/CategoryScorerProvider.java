package org.codingdojo.yatzy3.categories.provider;

import org.codingdojo.yatzy3.categories.CategoryScorer;

public interface CategoryScorerProvider {
    CategoryScorer getOnesNumberScorer();

    CategoryScorer getTwosNumberScorer();

    CategoryScorer getThreesNumberScorer();

    CategoryScorer getFoursNumberScorer();

    CategoryScorer getFivesNumberScorer();

    CategoryScorer getSixesNumberScorer();

    CategoryScorer getChanceScorer();

    CategoryScorer getYatzyPointerScorer();

    CategoryScorer getPairScorer();

    CategoryScorer getTwoPairsScorer();

    CategoryScorer getThreeOfKindScorer();

    CategoryScorer getFourOfKindScorer();

    CategoryScorer getSmallStraightScorer();

    CategoryScorer getLargeStraightScorer();

    CategoryScorer getFullHouseScorer();
}
