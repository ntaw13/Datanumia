package org.codingdojo.yatzy3.categories.provider;

public enum CategoryScorerFactory {
    INSTANCE;
    public static CategoryScorerFactory getInstance(){return INSTANCE;}

    final CategoryScorerProvider categoryScorerProvider = new CategoryScorerProviderImpl();

    public CategoryScorerProvider getCategoryScorerProvider() {
        return categoryScorerProvider;
    }
}
