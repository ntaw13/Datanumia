package org.codingdojo.yatzy3.categories;

import java.util.List;

public class ChanceScorer extends CategoryScorer {
    @Override
    public int calculateScore(List<Integer> dice) {
        return sum(dice);
    }
}
