package org.codingdojo.yatzy3.categories.provider;

import org.codingdojo.yatzy3.categories.*;

public class CategoryScorerProviderImpl implements CategoryScorerProvider {

    private static final int SMALL_STRAIGHT_SCORE = 15;
    private static final int LARGE_STRAIGHT_SCORE = 20;

    private CategoryScorer onesNumberScorer, twosNumberScorer, threesNumberScorer, foursNumberScorer, fivesNumberScorer,
        sixesNumberScorer, chanceScorer, yatzyPointerScorer, pairScorer, twoPairsScorer, threeOfKindScorer, fourOfKindScorer,
        smallStraightScorer, largeStraightScorer, fullHouseScorer;

    @Override
    public CategoryScorer getOnesNumberScorer() {
        if (this.onesNumberScorer == null) this.onesNumberScorer = new NumberScorer(1);
        return this.onesNumberScorer;
    }

    @Override
    public CategoryScorer getTwosNumberScorer() {
        if (this.twosNumberScorer == null) this.twosNumberScorer = new NumberScorer(2);
        return this.twosNumberScorer;
    }

    @Override
    public CategoryScorer getThreesNumberScorer() {
        if (this.threesNumberScorer == null) this.threesNumberScorer = new NumberScorer(3);
        return this.threesNumberScorer;
    }

    @Override
    public CategoryScorer getFoursNumberScorer() {
        if (this.foursNumberScorer == null) this.foursNumberScorer = new NumberScorer(4);
        return this.foursNumberScorer;
    }

    @Override
    public CategoryScorer getFivesNumberScorer() {
        if (this.fivesNumberScorer == null) this.fivesNumberScorer = new NumberScorer(5);
        return this.fivesNumberScorer;
    }

    @Override
    public CategoryScorer getSixesNumberScorer() {
        if (this.sixesNumberScorer == null) this.sixesNumberScorer = new NumberScorer(6);
        return this.sixesNumberScorer;
    }

    @Override
    public CategoryScorer getChanceScorer() {
        if (this.chanceScorer == null) this.chanceScorer = new ChanceScorer();
        return this.chanceScorer;
    }

    @Override
    public CategoryScorer getYatzyPointerScorer() {
        if (this.yatzyPointerScorer == null) this.yatzyPointerScorer = new YatzyPointsScorer();
        return this.yatzyPointerScorer;
    }

    @Override
    public CategoryScorer getPairScorer() {
        if (this.pairScorer == null) this.pairScorer = new RepeatedCountScorer(2);
        return this.pairScorer;
    }

    @Override
    public CategoryScorer getTwoPairsScorer() {
        if (this.twoPairsScorer == null) this.twoPairsScorer = new TwoPairsScorer();
        return this.twoPairsScorer;
    }

    @Override
    public CategoryScorer getThreeOfKindScorer() {
        if (this.threeOfKindScorer == null) this.threeOfKindScorer = new RepeatedCountScorer(3);
        return this.threeOfKindScorer;
    }

    @Override
    public CategoryScorer getFourOfKindScorer() {
        if (this.fourOfKindScorer == null) this.fourOfKindScorer = new RepeatedCountScorer(4);
        return this.fourOfKindScorer;
    }

    @Override
    public CategoryScorer getSmallStraightScorer() {
        if (this.smallStraightScorer == null) this.smallStraightScorer = new StraightScorer(SMALL_STRAIGHT_SCORE);
        return this.smallStraightScorer;
    }

    @Override
    public CategoryScorer getLargeStraightScorer() {
        if (this.largeStraightScorer == null) this.largeStraightScorer = new StraightScorer(LARGE_STRAIGHT_SCORE);
        return this.largeStraightScorer;
    }

    @Override
    public CategoryScorer getFullHouseScorer() {
        if (this.fullHouseScorer == null) this.fullHouseScorer = new FullHouseScorer();
        return this.fullHouseScorer;
    }
}
