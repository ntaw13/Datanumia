package org.codingdojo.yatzy3;

import org.codingdojo.YatzyCategory;
import org.codingdojo.yatzy3.categories.*;
import org.codingdojo.yatzy3.categories.provider.CategoryScorerFactory;
import org.codingdojo.yatzy3.categories.provider.CategoryScorerProvider;

public class ScorerManager {
    public static CategoryScorer getScorer(String categoryName) {
        YatzyCategory category = YatzyCategory.valueOf(categoryName);
        CategoryScorerProvider categoryScorerProvider = CategoryScorerFactory.getInstance().getCategoryScorerProvider();
        return switch (category) {
            case CHANCE -> categoryScorerProvider.getChanceScorer();
            case YATZY -> categoryScorerProvider.getYatzyPointerScorer();
            case ONES -> categoryScorerProvider.getOnesNumberScorer();
            case TWOS -> categoryScorerProvider.getTwosNumberScorer();
            case THREES -> categoryScorerProvider.getThreesNumberScorer();
            case FOURS -> categoryScorerProvider.getFoursNumberScorer();
            case FIVES -> categoryScorerProvider.getFivesNumberScorer();
            case SIXES -> categoryScorerProvider.getSixesNumberScorer();
            case PAIR -> categoryScorerProvider.getPairScorer();
            case THREE_OF_A_KIND -> categoryScorerProvider.getThreeOfKindScorer();
            case FOUR_OF_A_KIND -> categoryScorerProvider.getFourOfKindScorer();
            case SMALL_STRAIGHT -> categoryScorerProvider.getSmallStraightScorer();
            case LARGE_STRAIGHT -> categoryScorerProvider.getLargeStraightScorer();
            case TWO_PAIRS -> categoryScorerProvider.getTwoPairsScorer();
            case FULL_HOUSE -> categoryScorerProvider.getFullHouseScorer();
        };
    }

}
