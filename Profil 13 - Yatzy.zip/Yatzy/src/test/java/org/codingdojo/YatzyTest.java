package org.codingdojo;

import org.codingdojo.yatzy3.Yatzy3;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class YatzyTest {
    
    YatzyCalculator yatzy = new Yatzy3();

   @Test
    public void chance_scores_sum_of_all_dice() {
        assertEquals(15, yatzy.score(List.of(2,3,4,5,1), "CHANCE"));
        assertEquals(16, yatzy.score(List.of(3,3,4,5,1), "CHANCE"));
        assertEquals(21, yatzy.score(List.of(4,5,5,6,1), "CHANCE"));
    }

   @Test
    public void yatzy_scores_50() {
        assertEquals(50, yatzy.score(List.of(4,4,4,4,4), "YATZY"));
        assertEquals(50, yatzy.score(List.of(1,1,1,1,1), "YATZY"));
        assertEquals(50, yatzy.score(List.of(6,6,6,6,6), "YATZY"));
        assertEquals(0, yatzy.score(List.of(6,6,6,6,3), "YATZY"));
    }

   @Test
    public void ones_scores_sum_of_dice_read_one() {
        assertEquals(1, yatzy.score(List.of(1,2,3,4,5), "ONES"));
        assertEquals(2, yatzy.score(List.of(1,2,1,4,5), "ONES"));
        assertEquals(0, yatzy.score(List.of(6,2,2,4,5), "ONES"));
        assertEquals(4, yatzy.score(List.of(1,2,1,1,1), "ONES"));
    }

   @Test
    public void twos_scores_sum_of_dice_read_two() {
        assertEquals(4, yatzy.score(List.of(1,2,3,2,6), "TWOS"));
        assertEquals(10, yatzy.score(List.of(2,2,2,2,2), "TWOS"));
    }

   @Test
    public void threes_scores_sum_of_dice_read_three() {
        assertEquals(6, yatzy.score(List.of(1,2,3,2,3), "THREES"));
        assertEquals(12, yatzy.score(List.of(2,3,3,3,3), "THREES"));
    }

   @Test
    public void fours_scores_sum_of_dice_read_four()
    {
        assertEquals(12, yatzy.score(List.of(4,4,4,5,5), "FOURS"));
        assertEquals(8, yatzy.score(List.of(4,4,5,5,5), "FOURS"));
        assertEquals(4, yatzy.score(List.of(4,5,5,5,5), "FOURS"));
    }

   @Test
    public void fives_scores_sum_of_dice_read_five() {
        assertEquals(10, yatzy.score(List.of(4,4,4,5,5), "FIVES"));
        assertEquals(15, yatzy.score(List.of(4,4,5,5,5), "FIVES"));
        assertEquals(20, yatzy.score(List.of(4,5,5,5,5), "FIVES"));
    }
   @Test
    public void sixes_scores_sum_of_dice_read_six() {
        assertEquals(0, yatzy.score(List.of(4,4,4,5,5), "SIXES"));
        assertEquals(6, yatzy.score(List.of(4,4,6,5,5), "SIXES"));
        assertEquals(18, yatzy.score(List.of(6,5,6,6,5), "SIXES"));
    }

   @Test
    public void pair_scores_sum_of_two_highest_matching_dice() {
        assertEquals(6, yatzy.score(List.of(3,4,3,5,6), "PAIR"));
        assertEquals(10, yatzy.score(List.of(5,3,3,3,5), "PAIR"));
        assertEquals(12, yatzy.score(List.of(5,3,6,6,5), "PAIR"));
    }

   @Test
    public void twoPair_scores_sum_of_two_dice_same_number() {
        assertEquals(16, yatzy.score(List.of(3,3,5,4,5), "TWO_PAIRS"));
        assertEquals(16, yatzy.score(List.of(3,3,5,5,5), "TWO_PAIRS"));
    }

   @Test
    public void threeOfaKind_scores_sum_of_three_dice_same_number()
    {
        assertEquals(9, yatzy.score(List.of(3,3,3,4,5), "THREE_OF_A_KIND"));
        assertEquals(15, yatzy.score(List.of(5,3,5,4,5), "THREE_OF_A_KIND"));
        assertEquals(9, yatzy.score(List.of(3,3,3,3,5), "THREE_OF_A_KIND"));
    }

   @Test
    public void fourOfaKind_scores_sum_of_four_dice_same_number() {
        assertEquals(12, yatzy.score(List.of(3,3,3,3,5), "FOUR_OF_A_KIND"));
        assertEquals(20, yatzy.score(List.of(5,5,5,4,5), "FOUR_OF_A_KIND"));
        assertEquals(12, yatzy.score(List.of(3,3,3,3,3), "FOUR_OF_A_KIND"));
    }

   @Test
    public void smallStraight_scores_15_if_dice_read_12345() {
        assertEquals(15, yatzy.score(List.of(1,2,3,4,5), "SMALL_STRAIGHT"));
        assertEquals(15, yatzy.score(List.of(2,3,4,5,1), "SMALL_STRAIGHT"));
        assertEquals(0, yatzy.score(List.of(1,2,2,4,5), "SMALL_STRAIGHT"));
        assertEquals(0, yatzy.score(List.of(1,2,3,4,6), "SMALL_STRAIGHT"));
    }

   @Test
    public void largeStraight_scores_20_if_dice_read_23456() {
        assertEquals(20, yatzy.score(List.of(6,2,3,4,5), "LARGE_STRAIGHT"));
        assertEquals(20, yatzy.score(List.of(2,3,4,5,6), "LARGE_STRAIGHT"));
        assertEquals(0, yatzy.score(List.of(1,2,2,4,5), "LARGE_STRAIGHT"));
    }

   @Test
    public void fullHouse_scores_sum_of_all_dice_if_dice_are_two_of_kind_and_three_of_kind() {
        assertEquals(18, yatzy.score(List.of(6,2,2,2,6), "FULL_HOUSE"));
        assertEquals(0, yatzy.score(List.of(2,3,4,5,6), "FULL_HOUSE"));
    }
}
